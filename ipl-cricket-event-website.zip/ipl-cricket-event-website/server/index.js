import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "crypto";

const app = express();
const PORT = process.env.PORT || 4000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, "data");
const bookingsFile = path.join(dataDir, "bookings.json");

app.use(cors());
app.use(express.json());

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(bookingsFile)) fs.writeFileSync(bookingsFile, "[]");

const teams = [
  { id: "csk", name: "Chennai Super Kings", short: "CSK", city: "Chennai", color: "#f5c542", accent: "#1d3b75", titles: "5 titles (historical demo detail)", home: "M. A. Chidambaram Stadium" },
  { id: "mi", name: "Mumbai Indians", short: "MI", city: "Mumbai", color: "#2b72c4", accent: "#14345d", titles: "5 titles (historical demo detail)", home: "Wankhede Stadium" },
  { id: "rcb", name: "Royal Challengers Bengaluru", short: "RCB", city: "Bengaluru", color: "#d94242", accent: "#222222", titles: "1 title (historical demo detail)", home: "M. Chinnaswamy Stadium" },
  { id: "kkr", name: "Kolkata Knight Riders", short: "KKR", city: "Kolkata", color: "#8c63c7", accent: "#33204f", titles: "3 titles (historical demo detail)", home: "Eden Gardens" },
  { id: "srh", name: "Sunrisers Hyderabad", short: "SRH", city: "Hyderabad", color: "#ef7d32", accent: "#4d261c", titles: "1 title (historical demo detail)", home: "Rajiv Gandhi International Cricket Stadium" },
  { id: "rr", name: "Rajasthan Royals", short: "RR", city: "Jaipur", color: "#ec79b5", accent: "#283f85", titles: "1 title (historical demo detail)", home: "Sawai Mansingh Stadium" },
  { id: "dc", name: "Delhi Capitals", short: "DC", city: "Delhi", color: "#4a83ce", accent: "#c93c50", titles: "Team profile demo", home: "Arun Jaitley Stadium" },
  { id: "pbks", name: "Punjab Kings", short: "PBKS", city: "Punjab", color: "#d94c57", accent: "#681d2a", titles: "Team profile demo", home: "New PCA Stadium" },
  { id: "lsg", name: "Lucknow Super Giants", short: "LSG", city: "Lucknow", color: "#55a8c8", accent: "#e28b39", titles: "Team profile demo", home: "BRSABV Ekana Cricket Stadium" },
  { id: "gt", name: "Gujarat Titans", short: "GT", city: "Ahmedabad", color: "#5a7b9f", accent: "#c6a96c", titles: "1 title (historical demo detail)", home: "Narendra Modi Stadium" }
];

const matches = [
  { id: 1, date: "2026-11-07", time: "19:30", home: "rcb", away: "mi", venue: "M. Chinnaswamy Stadium", city: "Bengaluru", status: "UPCOMING", label: "DEMO FIXTURE" },
  { id: 2, date: "2026-11-08", time: "15:30", home: "csk", away: "kkr", venue: "M. A. Chidambaram Stadium", city: "Chennai", status: "UPCOMING", label: "DEMO FIXTURE" },
  { id: 3, date: "2026-11-09", time: "19:30", home: "srh", away: "rr", venue: "Rajiv Gandhi International Cricket Stadium", city: "Hyderabad", status: "UPCOMING", label: "DEMO FIXTURE" },
  { id: 4, date: "2026-11-10", time: "19:30", home: "dc", away: "pbks", venue: "Arun Jaitley Stadium", city: "Delhi", status: "UPCOMING", label: "DEMO FIXTURE" },
  { id: 5, date: "2026-11-11", time: "19:30", home: "gt", away: "lsg", venue: "Narendra Modi Stadium", city: "Ahmedabad", status: "UPCOMING", label: "DEMO FIXTURE" },
  { id: 6, date: "2026-11-12", time: "19:30", home: "mi", away: "csk", venue: "Wankhede Stadium", city: "Mumbai", status: "UPCOMING", label: "DEMO FIXTURE" }
];

function readBookings() {
  try { return JSON.parse(fs.readFileSync(bookingsFile, "utf8")); }
  catch { return []; }
}
function writeBookings(items) {
  fs.writeFileSync(bookingsFile, JSON.stringify(items, null, 2));
}

app.get("/api/health", (_req, res) => res.json({ ok: true, message: "IPL demo API is running" }));
app.get("/api/teams", (_req, res) => res.json(teams));
app.get("/api/matches", (_req, res) => res.json(matches));

app.get("/api/bookings", (_req, res) => {
  const bookings = readBookings().map(({ customer, ...safe }) => safe);
  res.json(bookings);
});

app.post("/api/bookings", (req, res) => {
  const { matchId, category, quantity, name, email, phone } = req.body || {};
  if (!matchId || !category || !name?.trim() || !email?.trim() || !phone?.trim()) {
    return res.status(400).json({ error: "Please complete all required booking fields." });
  }
  const qty = Number(quantity);
  if (!Number.isInteger(qty) || qty < 1 || qty > 6) {
    return res.status(400).json({ error: "You can book between 1 and 6 tickets." });
  }
  const match = matches.find(m => m.id === Number(matchId));
  if (!match) return res.status(404).json({ error: "Match not found." });

  const prices = { "General Stand": 900, "Premium Stand": 1800, "VIP Lounge": 4500 };
  if (!prices[category]) return res.status(400).json({ error: "Invalid ticket category." });

  const booking = {
    id: `IPL-${crypto.randomBytes(3).toString("hex").toUpperCase()}`,
    matchId: match.id,
    match: `${teams.find(t => t.id === match.home).short} vs ${teams.find(t => t.id === match.away).short}`,
    venue: match.venue,
    date: match.date,
    category,
    quantity: qty,
    amount: prices[category] * qty,
    status: "DEMO BOOKING — PAYMENT NOT TAKEN",
    createdAt: new Date().toISOString(),
    customer: { name: name.trim(), email: email.trim(), phone: phone.trim() }
  };
  const bookings = readBookings();
  bookings.unshift(booking);
  writeBookings(bookings);
  res.status(201).json({
    id: booking.id,
    match: booking.match,
    venue: booking.venue,
    date: booking.date,
    category: booking.category,
    quantity: booking.quantity,
    amount: booking.amount,
    status: booking.status
  });
});

app.get("/api/admin/stats", (_req, res) => {
  const bookings = readBookings();
  res.json({
    bookings: bookings.length,
    tickets: bookings.reduce((sum, b) => sum + b.quantity, 0),
    demoValue: bookings.reduce((sum, b) => sum + b.amount, 0)
  });
});

const frontendDist = path.resolve(__dirname, "../client/dist");
if (fs.existsSync(frontendDist)) {
  app.use(express.static(frontendDist));
  app.get("*", (_req, res) => res.sendFile(path.join(frontendDist, "index.html")));
} else {
  app.get("/", (_req, res) => res.json({ message: "IPL Cricket Event Website API is running. Start the Vite client for the website." }));
}

app.listen(PORT, () => console.log(`IPL API running on http://localhost:${PORT}`));
