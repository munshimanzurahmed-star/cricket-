import React, { useEffect, useMemo, useState } from "react";
import { QRCodeCanvas } from "qrcode.react";
import {
  Activity, ArrowRight, CalendarDays, Check, ChevronDown, CircleHelp,
  Clock3, MapPin, Menu, Search, ShieldCheck, Ticket, Trophy, Users,
  X, Zap, PlayCircle, LayoutDashboard, Mail, Phone, ExternalLink
} from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:4000";
const fallbackTeams = [
  ["csk","Chennai Super Kings","CSK","Chennai","#f5c542","#1d3b75","M. A. Chidambaram Stadium"],
  ["mi","Mumbai Indians","MI","Mumbai","#2b72c4","#14345d","Wankhede Stadium"],
  ["rcb","Royal Challengers Bengaluru","RCB","Bengaluru","#d94242","#222222","M. Chinnaswamy Stadium"],
  ["kkr","Kolkata Knight Riders","KKR","Kolkata","#8c63c7","#33204f","Eden Gardens"],
  ["srh","Sunrisers Hyderabad","SRH","Hyderabad","#ef7d32","#4d261c","Rajiv Gandhi International Cricket Stadium"],
  ["rr","Rajasthan Royals","RR","Jaipur","#ec79b5","#283f85","Sawai Mansingh Stadium"],
  ["dc","Delhi Capitals","DC","Delhi","#4a83ce","#c93c50","Arun Jaitley Stadium"],
  ["pbks","Punjab Kings","PBKS","Punjab","#d94c57","#681d2a","New PCA Stadium"],
  ["lsg","Lucknow Super Giants","LSG","Lucknow","#55a8c8","#e28b39","BRSABV Ekana Cricket Stadium"],
  ["gt","Gujarat Titans","GT","Ahmedabad","#5a7b9f","#c6a96c","Narendra Modi Stadium"]
].map(([id,name,short,city,color,accent,home]) => ({id,name,short,city,color,accent,home}));

const fallbackMatches = [
  {id:1,date:"2026-11-07",time:"19:30",home:"rcb",away:"mi",venue:"M. Chinnaswamy Stadium",city:"Bengaluru",status:"UPCOMING",label:"DEMO FIXTURE"},
  {id:2,date:"2026-11-08",time:"15:30",home:"csk",away:"kkr",venue:"M. A. Chidambaram Stadium",city:"Chennai",status:"UPCOMING",label:"DEMO FIXTURE"},
  {id:3,date:"2026-11-09",time:"19:30",home:"srh",away:"rr",venue:"Rajiv Gandhi International Cricket Stadium",city:"Hyderabad",status:"UPCOMING",label:"DEMO FIXTURE"},
  {id:4,date:"2026-11-10",time:"19:30",home:"dc",away:"pbks",venue:"Arun Jaitley Stadium",city:"Delhi",status:"UPCOMING",label:"DEMO FIXTURE"},
  {id:5,date:"2026-11-11",time:"19:30",home:"gt",away:"lsg",venue:"Narendra Modi Stadium",city:"Ahmedabad",status:"UPCOMING",label:"DEMO FIXTURE"},
  {id:6,date:"2026-11-12",time:"19:30",home:"mi",away:"csk",venue:"Wankhede Stadium",city:"Mumbai",status:"UPCOMING",label:"DEMO FIXTURE"}
];

const money = n => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n);
const dateLabel = d => new Date(`${d}T00:00:00`).toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"});
const timeLabel = t => {
  const [h,m] = t.split(":").map(Number);
  return `${((h+11)%12)+1}:${String(m).padStart(2,"0")} ${h>=12?"PM":"AM"} IST`;
};

function App() {
  const [page,setPage] = useState("home");
  const [teams,setTeams] = useState(fallbackTeams);
  const [matches,setMatches] = useState(fallbackMatches);
  const [bookings,setBookings] = useState([]);
  const [selectedMatch,setSelectedMatch] = useState(null);
  const [booking,setBooking] = useState(null);
  const [menuOpen,setMenuOpen] = useState(false);
  const [filter,setFilter] = useState("all");
  const [query,setQuery] = useState("");
  const [apiOnline,setApiOnline] = useState(false);
  const [notice,setNotice] = useState("");

  useEffect(() => {
    Promise.all([
      fetch(`${API}/api/teams`).then(r=>r.ok?r.json():Promise.reject()).catch(()=>fallbackTeams),
      fetch(`${API}/api/matches`).then(r=>r.ok?r.json():Promise.reject()).catch(()=>fallbackMatches),
      fetch(`${API}/api/bookings`).then(r=>r.ok?r.json():Promise.reject()).catch(()=>[])
    ]).then(([t,m,b]) => { setTeams(t); setMatches(m); setBookings(b); setApiOnline(true); })
      .catch(()=>setApiOnline(false));
  }, []);

  const teamById = id => teams.find(t=>t.id===id) || fallbackTeams.find(t=>t.id===id);
  const go = p => { setPage(p); setMenuOpen(false); window.scrollTo({top:0,behavior:"smooth"}); };
  const openBooking = match => { setSelectedMatch(match); setBooking(null); setPage("book"); window.scrollTo({top:0,behavior:"smooth"}); };
  const nav = [
    ["home","Home"],["matches","Matches"],["teams","Teams"],["scores","Live scores"],["stadiums","Stadiums"],["gallery","Gallery"],["help","Help"]
  ];

  async function refreshBookings() {
    try { const r=await fetch(`${API}/api/bookings`); if(r.ok) setBookings(await r.json()); } catch {}
  }

  return <div className="app-shell">
    <div className="topline"><span><Zap size={13}/> THE CRICKET EXPERIENCE</span><span className="demo-note">INDEPENDENT DEMO WEBSITE · NOT OFFICIAL IPL</span></div>
    <header className="header">
      <button className="brand" onClick={()=>go("home")} aria-label="Go home">
        <span className="brand-mark"><Trophy size={22}/></span><span>BOUNDARY<span className="brand-dot">.</span><small>CRICKET EVENT HUB</small></span>
      </button>
      <nav className="desktop-nav">{nav.map(([id,label])=><button key={id} className={page===id?"active":""} onClick={()=>go(id)}>{label}</button>)}</nav>
      <div className="header-actions">
        <button className="admin-link" onClick={()=>go("admin")}><LayoutDashboard size={16}/> Admin</button>
        <button className="primary small" onClick={()=>openBooking(matches[0])}><Ticket size={16}/> Book tickets</button>
        <button className="mobile-menu" onClick={()=>setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen?<X/>:<Menu/>}</button>
      </div>
    </header>
    {menuOpen && <nav className="mobile-nav">{nav.map(([id,label])=><button key={id} onClick={()=>go(id)}>{label}</button>)}<button onClick={()=>go("admin")}>Admin dashboard</button></nav>}
    <main>
      {page==="home" && <Home teams={teams} matches={matches} teamById={teamById} onNavigate={go} onBook={openBooking}/>}
      {page==="matches" && <Matches matches={matches} teamById={teamById} onBook={openBooking}/>}
      {page==="teams" && <Teams teams={teams}/>}
      {page==="scores" && <Scores matches={matches} teamById={teamById}/>}
      {page==="stadiums" && <Stadiums teams={teams}/>}
      {page==="gallery" && <Gallery/>}
      {page==="help" && <Help/>}
      {page==="book" && <Booking match={selectedMatch || matches[0]} teamById={teamById} onComplete={async b=>{setBooking(b); await refreshBookings();}} booking={booking} apiOnline={apiOnline}/>}
      {page==="admin" && <Admin bookings={bookings} apiOnline={apiOnline} onRefresh={refreshBookings}/>}
    </main>
    <footer className="footer">
      <div className="footer-main"><div className="brand footer-brand"><span className="brand-mark"><Trophy size={22}/></span><span>BOUNDARY<span className="brand-dot">.</span><small>CRICKET EVENT HUB</small></span></div><p>Your home for match days, teams, tickets and the electric atmosphere of T20 cricket.</p><div className="footer-links">{nav.slice(0,5).map(([id,label])=><button key={id} onClick={()=>go(id)}>{label}</button>)}</div></div>
      <div className="footer-bottom"><span>© 2026 Boundary Cricket Event Hub. Student project demo.</span><span>Independent project · Not affiliated with IPL or BCCI.</span></div>
    </footer>
    {notice && <div className="toast"><Check size={16}/>{notice}<button onClick={()=>setNotice("")}><X size={14}/></button></div>}
  </div>;
}

function SectionTitle({eyebrow,title,description,action}) {
  return <div className="section-title"><div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2>{description&&<p>{description}</p>}</div>{action}</div>;
}

function TeamBadge({team,large=false}) {
  return <div className={`team-badge ${large?"large":""}`} style={{"--team":team?.color||"#e87928","--accent":team?.accent||"#222"}}><span>{team?.short||"TBD"}</span></div>;
}

function MatchCard({match,teamById,onBook}) {
  const a=teamById(match.home), b=teamById(match.away);
  return <article className="match-card">
    <div className="match-card-top"><span className="status"><i/> {match.status}</span><span className="demo-tag">{match.label||"DEMO FIXTURE"}</span></div>
    <div className="match-date"><CalendarDays size={14}/>{dateLabel(match.date)} <span>·</span> {timeLabel(match.time)}</div>
    <div className="versus">
      <div className="versus-team"><TeamBadge team={a}/><b>{a?.short}</b><small>{a?.city}</small></div>
      <span className="vs">VS</span>
      <div className="versus-team"><TeamBadge team={b}/><b>{b?.short}</b><small>{b?.city}</small></div>
    </div>
    <div className="match-venue"><MapPin size={14}/>{match.venue}, {match.city}</div>
    <button className="outline full" onClick={()=>onBook(match)}>Book tickets <ArrowRight size={15}/></button>
  </article>;
}

function Home({teams,matches,teamById,onNavigate,onBook}) {
  const next=matches[0];
  const [timeLeft,setTimeLeft]=useState({d:"--",h:"--",m:"--",s:"--"});
  useEffect(()=>{
    const update=()=>{
      const target=new Date(`${next.date}T${next.time}:00+05:30`).getTime();
      const diff=Math.max(0,target-Date.now());
      setTimeLeft({d:String(Math.floor(diff/86400000)).padStart(2,"0"),h:String(Math.floor(diff/3600000)%24).padStart(2,"0"),m:String(Math.floor(diff/60000)%60).padStart(2,"0"),s:String(Math.floor(diff/1000)%60).padStart(2,"0")});
    };
    update(); const timer=setInterval(update,1000); return ()=>clearInterval(timer);
  },[next]);
  return <>
    <section className="hero">
      <div className="hero-bg"></div><div className="hero-grain"></div>
      <div className="hero-content">
        <div className="hero-kicker"><span className="live-pulse"></span> THE GAME. THE CROWD. THE GLORY.</div>
        <h1>WHERE EVERY<br/><em>OVER</em> MATTERS<span className="orange">.</span></h1>
        <p>Feel the roar. Follow every ball. Make every match day unforgettable.</p>
        <div className="hero-buttons"><button className="primary" onClick={()=>onBook(next)}><Ticket size={17}/> Book your seat</button><button className="ghost" onClick={()=>onNavigate("matches")}><PlayCircle size={17}/> Explore matches</button></div>
        <div className="hero-stats"><div><b>10</b><span>TEAMS</span></div><div><b>T20</b><span>FORMAT</span></div><div><b>1</b><span>BIG DREAM</span></div></div>
      </div>
      <div className="hero-side-label">CRICKET · CULTURE · COMMUNITY</div>
      <div className="hero-bottom"><span>SCROLL TO EXPLORE</span><span className="scroll-line"></span><span>01 / 06</span></div>
    </section>
    <section className="next-match-section wrap">
      <div className="next-match-card">
        <div className="next-left"><span className="eyebrow">UP NEXT · DEMO FIXTURE</span><h2>THE NEXT<br/><span>SHOWDOWN</span></h2><p><MapPin size={15}/> {next.venue}, {next.city}</p><div className="countdown"><div><b>{timeLeft.d}</b><small>DAYS</small></div><div><b>{timeLeft.h}</b><small>HRS</small></div><div><b>{timeLeft.m}</b><small>MIN</small></div><div><b>{timeLeft.s}</b><small>SEC</small></div></div><button className="primary" onClick={()=>onBook(next)}>Get tickets <ArrowRight size={16}/></button></div>
        <div className="next-right"><div className="next-date">{dateLabel(next.date)} <span>·</span> {timeLabel(next.time)}</div><div className="big-versus"><div><TeamBadge team={teamById(next.home)} large/><b>{teamById(next.home)?.short}</b><small>{teamById(next.home)?.name}</small></div><span>VS</span><div><TeamBadge team={teamById(next.away)} large/><b>{teamById(next.away)?.short}</b><small>{teamById(next.away)?.name}</small></div></div><div className="fixture-label">DEMO MATCH · SCHEDULE SUBJECT TO CHANGE</div></div>
      </div>
    </section>
    <section className="wrap section-block"><SectionTitle eyebrow="THE LINE-UP" title="10 teams. One trophy." description="Explore the teams bringing the energy to every match day." action={<button className="text-link" onClick={()=>onNavigate("teams")}>View all teams <ArrowRight size={15}/></button>}/><div className="team-grid">{teams.slice(0,5).map(t=><TeamTile key={t.id} team={t}/>)}</div></section>
    <section className="dark-band"><div className="wrap band-inner"><div><span className="eyebrow">DON'T MISS A MOMENT</span><h2>YOUR MATCH DAY<br/><span>STARTS HERE.</span></h2></div><button className="primary" onClick={()=>onNavigate("matches")}>View match schedule <ArrowRight size={16}/></button></div></section>
    <section className="wrap section-block"><SectionTitle eyebrow="ON THE CALENDAR" title="Upcoming fixtures" description="Plan your next stadium experience. All fixtures below are illustrative demo data." action={<button className="text-link" onClick={()=>onNavigate("matches")}>Full schedule <ArrowRight size={15}/></button>}/><div className="match-grid">{matches.slice(0,3).map(m=><MatchCard key={m.id} match={m} teamById={teamById} onBook={onBook}/>)}</div></section>
  </>;
}

function TeamTile({team}) {
  return <article className="team-tile" style={{"--team":team.color,"--accent":team.accent}}><div className="team-tile-glow"></div><TeamBadge team={team} large/><b>{team.short}</b><span>{team.name}</span><small>{team.city.toUpperCase()}</small></article>;
}

function Teams({teams}) {
  const [selected,setSelected]=useState(null);
  return <div className="page-wrap wrap"><SectionTitle eyebrow="THE FRANCHISES" title="Meet the teams" description="Ten team identities. One shared love for the game. Select a team to explore its profile."/><div className="team-grid full-team-grid">{teams.map(t=><button className="team-tile clickable" key={t.id} style={{"--team":t.color,"--accent":t.accent}} onClick={()=>setSelected(t)}><div className="team-tile-glow"></div><TeamBadge team={t} large/><b>{t.short}</b><span>{t.name}</span><small>{t.city.toUpperCase()}</small></button>)}</div>
    {selected&&<div className="modal-backdrop" onClick={()=>setSelected(null)}><div className="team-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setSelected(null)}><X/></button><TeamBadge team={selected} large/><span className="eyebrow">TEAM PROFILE</span><h2>{selected.name}</h2><p>Based in {selected.city}. Home venue: {selected.home}.</p><div className="profile-stat"><span>Historical achievement note</span><b>{selected.titles}</b></div><p className="muted">Captain and player roster details are not included in this demo. Add verified current-season information before publishing.</p></div></div>}
  </div>;
}

function Matches({matches,teamById,onBook}) {
  const [filter,setFilter]=useState("all");
  const [search,setSearch]=useState("");
  const filtered=matches.filter(m=>(filter==="all"||m.home===filter||m.away===filter)&&(`${teamById(m.home)?.name} ${teamById(m.away)?.name} ${m.city}`.toLowerCase().includes(search.toLowerCase())));
  return <div className="page-wrap wrap"><SectionTitle eyebrow="FIXTURE LIST" title="Match schedule" description="Find your next match day. The fixtures shown are sample data for this website prototype."/><div className="filter-bar"><div className="searchbox"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search team or city..."/></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">All teams</option>{[...teamsForSelect()].map(t=><option key={t.id} value={t.id}>{t.short}</option>)}</select></div><div className="match-grid">{filtered.map(m=><MatchCard key={m.id} match={m} teamById={teamById} onBook={onBook}/>)}</div>{!filtered.length&&<div className="empty">No fixtures match your search.</div>}</div>;
}
function teamsForSelect(){return fallbackTeams;}

function Scores({matches,teamById}) {
  return <div className="page-wrap wrap"><SectionTitle eyebrow="BALL BY BALL FEELING" title="Live centre" description="This screen demonstrates a live-score layout. No live score feed is connected."/><div className="score-warning"><Activity size={17}/> DEMO SCOREBOARD · NOT LIVE MATCH DATA</div><div className="score-feature"><div className="score-feature-top"><span className="status"><i/> SAMPLE SCORE</span><span>DEMO DATA ONLY</span></div><div className="score-teams"><div><TeamBadge team={teamById("rcb")} large/><h3>RCB</h3><b>178/6</b><small>20.0 overs</small></div><span className="score-vs">VS</span><div><TeamBadge team={teamById("mi")} large/><h3>MI</h3><b>164/8</b><small>19.4 overs</small></div></div><div className="score-result">Sample result: RCB won by 14 runs.</div><div className="score-details"><div><span>RUN RATE</span><b>8.90</b></div><div><span>TOP BATTER</span><b>82 (48)</b></div><div><span>BEST BOWLER</span><b>3/24</b></div></div></div><h3 className="subheading">Upcoming matches</h3><div className="match-grid">{matches.slice(0,3).map(m=><div className="mini-fixture" key={m.id}><span>{dateLabel(m.date)} · {timeLabel(m.time)}</span><b>{teamById(m.home)?.short} <i>vs</i> {teamById(m.away)?.short}</b><small>{m.venue}</small></div>)}</div></div>;
}

const stadiums=[
  ["M. Chinnaswamy Stadium","Bengaluru","Karnataka","Compact city-centre venue known for an energetic crowd.","M. Chinnaswamy Stadium Bengaluru"],
  ["Wankhede Stadium","Mumbai","Maharashtra","A famous coastal cricket venue in the heart of Mumbai.","Wankhede Stadium Mumbai"],
  ["Eden Gardens","Kolkata","West Bengal","One of India's historic cricket grounds.","Eden Gardens Kolkata"],
  ["Narendra Modi Stadium","Ahmedabad","Gujarat","A large modern cricket stadium.","Narendra Modi Stadium Ahmedabad"],
  ["M. A. Chidambaram Stadium","Chennai","Tamil Nadu","A historic cricket venue with a passionate fan base.","MA Chidambaram Stadium Chennai"],
  ["Rajiv Gandhi International Cricket Stadium","Hyderabad","Telangana","A major international cricket venue.","Rajiv Gandhi International Cricket Stadium Hyderabad"]
];
function Stadiums() {
  return <div className="page-wrap wrap"><SectionTitle eyebrow="THE VENUES" title="Stadium guide" description="Explore selected Indian cricket venues. Confirm match-specific entry, parking and facility details with the venue before travel."/><div className="stadium-grid">{stadiums.map((s,i)=><article className="stadium-card" key={s[0]}><div className={`stadium-art stadium-art-${i%3}`}><span>VENUE 0{i+1}</span><MapPin size={28}/></div><div className="stadium-info"><span className="eyebrow">{s[2].toUpperCase()}</span><h3>{s[0]}</h3><p>{s[3]}</p><div className="stadium-city"><MapPin size={14}/>{s[1]}, India</div><a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(s[4])}`} target="_blank" rel="noreferrer">Open map <ExternalLink size={14}/></a></div></article>)}</div></div>;
}

function Gallery() {
  const items=["Stadium lights","The big moment","Match day energy","The crowd","Game on","Trophy dreams"];
  return <div className="page-wrap wrap"><SectionTitle eyebrow="THE ATMOSPHERE" title="Match day gallery" description="A visual moodboard for the cricket event experience. Replace these gradient panels with licensed event photographs."/><div className="gallery-grid">{items.map((x,i)=><div className={`gallery-card gallery-${i+1}`} key={x}><span>BOUNDARY / 0{i+1}</span><b>{x}</b></div>)}</div></div>;
}

function Help() {
  const [open,setOpen]=useState(0);
  const faqs=[
    ["Are these official IPL fixtures?","No. This is an independent student website prototype. The fixtures, scores and ticket prices are demonstration content."],
    ["Can I make a real ticket purchase?","No real payment is processed. The booking form creates a demo booking reference only."],
    ["How do I receive a ticket?","After submitting the demo form, a booking reference and QR code are displayed. It is not valid for stadium entry."],
    ["How can I get a refund?","No payment is taken in this prototype, so no refund is due. Add a verified ticketing provider and published refund policy before launch."],
    ["How can I contact the organisers?","This demo does not have a staffed support team. Replace the sample contact details with your project or event organiser's details."]
  ];
  return <div className="page-wrap wrap"><SectionTitle eyebrow="WE'RE HERE TO HELP" title="Help & FAQs" description="Answers to common questions about this student website prototype."/><div className="help-layout"><div className="help-card"><h3>Frequently asked questions</h3>{faqs.map(([q,a],i)=><div className="faq" key={q}><button onClick={()=>setOpen(open===i?-1:i)}>{q}<ChevronDown className={open===i?"rotated":""} size={18}/></button>{open===i&&<p>{a}</p>}</div>)}</div><div className="support-card"><CircleHelp size={28}/><h3>Need more help?</h3><p>For a real event, add verified organiser contact information here.</p><div><Mail size={15}/> support@example.com</div><div><Phone size={15}/> +91 00000 00000</div><small>Sample contact details — replace before publishing.</small></div></div></div>;
}

function Booking({match,teamById,onComplete,booking,apiOnline}) {
  const [form,setForm]=useState({name:"",email:"",phone:"",category:"General Stand",quantity:1});
  const [error,setError]=useState("");
  const [loading,setLoading]=useState(false);
  const prices={"General Stand":900,"Premium Stand":1800,"VIP Lounge":4500};
  const total=prices[form.category]*Number(form.quantity);
  const set=(k,v)=>setForm(f=>({...f,[k]:v}));
  async function submit(e) {
    e.preventDefault();setError("");
    if(!form.name.trim()||!form.email.trim()||!form.phone.trim()){setError("Please complete all fields.");return;}
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)){setError("Enter a valid email address.");return;}
    if(!/^[0-9+\-\s]{8,15}$/.test(form.phone)){setError("Enter a valid phone number.");return;}
    setLoading(true);
    try {
      const r=await fetch(`${API}/api/bookings`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({matchId:match.id,...form})});
      const data=await r.json();
      if(!r.ok)throw new Error(data.error||"Booking could not be created.");
      onComplete(data);
    } catch(err) {
      const demo={id:`LOCAL-${Math.random().toString(36).slice(2,8).toUpperCase()}`,match:`${teamById(match.home).short} vs ${teamById(match.away).short}`,venue:match.venue,date:match.date,category:form.category,quantity:Number(form.quantity),amount:total,status:"LOCAL DEMO — PAYMENT NOT TAKEN"};
      onComplete(demo);
    } finally {setLoading(false);}
  }
  if(booking) return <div className="page-wrap wrap"><div className="booking-success"><div className="success-icon"><Check size={32}/></div><span className="eyebrow">DEMO BOOKING CREATED</span><h2>Your match day plan is ready.</h2><p>No payment has been taken. This is not a valid stadium ticket.</p><div className="ticket-preview"><div className="ticket-preview-main"><div className="ticket-brand">BOUNDARY <span>· DEMO PASS</span></div><h3>{booking.match}</h3><p><CalendarDays size={15}/>{dateLabel(booking.date)}</p><p><MapPin size={15}/>{booking.venue}</p><div className="ticket-meta"><span>BOOKING REF<strong>{booking.id}</strong></span><span>QUANTITY<strong>{booking.quantity}</strong></span><span>AMOUNT<strong>{money(booking.amount)}</strong></span></div><small>{booking.status}</small></div><div className="ticket-qr"><QRCodeCanvas value={JSON.stringify({ref:booking.id,match:booking.match,date:booking.date})} size={124}/><small>DEMO QR · NOT VALID FOR ENTRY</small></div></div><button className="primary" onClick={()=>window.print()}>Print demo confirmation</button></div></div>;
  return <div className="page-wrap wrap booking-page"><SectionTitle eyebrow="SECURE YOUR SEAT" title="Book your tickets" description="Complete the form to create a sample booking. No payment is collected."/><div className="booking-layout"><form className="booking-form" onSubmit={submit}><div className="form-section-head"><span>01</span><div><h3>Choose your match</h3><p>Selected fixture · demo schedule</p></div></div><div className="selected-match"><div className="selected-logos"><TeamBadge team={teamById(match.home)}/><b>{teamById(match.home).short} <i>VS</i> {teamById(match.away).short}</b><TeamBadge team={teamById(match.away)}/></div><span>{dateLabel(match.date)} · {timeLabel(match.time)}</span><small><MapPin size={13}/>{match.venue}</small></div>
    <div className="form-section-head"><span>02</span><div><h3>Ticket preferences</h3><p>Choose a category and quantity</p></div></div>
    <label>Ticket category<select value={form.category} onChange={e=>set("category",e.target.value)}>{Object.entries(prices).map(([k,v])=><option key={k} value={k}>{k} — {money(v)} / ticket</option>)}</select></label>
    <label>Number of tickets<select value={form.quantity} onChange={e=>set("quantity",e.target.value)}>{[1,2,3,4,5,6].map(n=><option key={n} value={n}>{n} {n===1?"ticket":"tickets"}</option>)}</select></label>
    <div className="form-section-head"><span>03</span><div><h3>Your details</h3><p>Used only for this local demo booking</p></div></div>
    <div className="form-grid"><label>Full name<input value={form.name} onChange={e=>set("name",e.target.value)} placeholder="Your name" required/></label><label>Email address<input type="email" value={form.email} onChange={e=>set("email",e.target.value)} placeholder="you@example.com" required/></label><label className="span-2">Mobile number<input value={form.phone} onChange={e=>set("phone",e.target.value)} placeholder="+91 98765 43210" required/></label></div>
    {error&&<div className="form-error">{error}</div>}<button className="primary full" disabled={loading}>{loading?"Creating booking...":<>Create demo booking <ArrowRight size={16}/></>}</button><p className="fine-print"><ShieldCheck size={14}/> Demo only. No payment gateway is connected and no real ticket is issued.</p>
    </form><aside className="order-summary"><span className="eyebrow">BOOKING SUMMARY</span><h3>Your selection</h3><div className="summary-row"><span>Ticket type</span><b>{form.category}</b></div><div className="summary-row"><span>Price per ticket</span><b>{money(prices[form.category])}</b></div><div className="summary-row"><span>Quantity</span><b>{form.quantity}</b></div><div className="summary-total"><span>Demo total</span><b>{money(total)}</b></div><div className="summary-note"><ShieldCheck size={17}/><span>No real payment will be taken. Prices are illustrative and not official ticket prices.</span></div><div className="api-status"><i className={apiOnline?"online":""}></i>{apiOnline?"Demo booking API connected":"Local demo mode"}</div></aside></div></div>;
}

function Admin({bookings,apiOnline,onRefresh}) {
  const [stats,setStats]=useState({bookings:bookings.length,tickets:bookings.reduce((s,b)=>s+(b.quantity||0),0),demoValue:bookings.reduce((s,b)=>s+(b.amount||0),0)});
  useEffect(()=>{fetch(`${API}/api/admin/stats`).then(r=>r.ok?r.json():null).then(x=>x&&setStats(x)).catch(()=>{});},[bookings]);
  const exportCsv=()=>{
    const rows=[["Booking ID","Match","Venue","Date","Category","Quantity","Demo Amount","Status"],...bookings.map(b=>[b.id,b.match,b.venue,b.date,b.category,b.quantity,b.amount,b.status])];
    const csv=rows.map(r=>r.map(v=>`"${String(v??"").replaceAll('"','""')}"`).join(",")).join("\n");
    const url=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));const a=document.createElement("a");a.href=url;a.download="ipl-demo-bookings.csv";a.click();URL.revokeObjectURL(url);
  };
  return <div className="page-wrap wrap"><SectionTitle eyebrow="ORGANISER VIEW" title="Admin dashboard" description="Classroom prototype dashboard. This page is not protected by admin authentication." action={<button className="outline" onClick={onRefresh}>Refresh data</button>}/><div className="admin-warning"><ShieldCheck size={17}/> Demo admin panel — do not use for real customer or payment data.</div><div className="stats-grid"><div className="stat-card"><span>TOTAL BOOKINGS</span><b>{stats.bookings}</b><small>Sample bookings</small></div><div className="stat-card"><span>TICKETS RESERVED</span><b>{stats.tickets}</b><small>Demo ticket quantity</small></div><div className="stat-card"><span>DEMO BOOKING VALUE</span><b>{money(stats.demoValue)}</b><small>Not actual revenue</small></div><div className="stat-card"><span>API STATUS</span><b className="api-big">{apiOnline?"ONLINE":"LOCAL"}</b><small>Development service</small></div></div><div className="admin-table-head"><h3>Recent bookings</h3><button className="outline" onClick={exportCsv}>Export CSV</button></div><div className="table-wrap"><table><thead><tr><th>Booking</th><th>Match</th><th>Date</th><th>Category</th><th>Qty</th><th>Amount</th><th>Status</th></tr></thead><tbody>{bookings.map(b=><tr key={b.id}><td>{b.id}</td><td>{b.match}</td><td>{b.date}</td><td>{b.category}</td><td>{b.quantity}</td><td>{money(b.amount)}</td><td><span className="table-status">DEMO</span></td></tr>)}{!bookings.length&&<tr><td colSpan="7" className="empty-cell">No demo bookings yet. Create a booking to see it here.</td></tr>}</tbody></table></div></div>;
}

